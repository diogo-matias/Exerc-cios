const idade: number = -9;

if (idade > 0) {
  console.log(idade >= 18 ? "Pode dirigir..." : "Não pode dirigir...");
} else {
  console.log("ERRO: Idade negativa");
}
