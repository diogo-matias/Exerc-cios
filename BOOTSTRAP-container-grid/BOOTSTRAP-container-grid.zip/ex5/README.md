# Atividade-Front-End-I

<img src="./images/preview_2.png" alt="minha_foto" />
<img src="./images/preview_1.png" alt="minha_foto" />
<img src="./images/preview_3.png" alt="minha_foto" />
